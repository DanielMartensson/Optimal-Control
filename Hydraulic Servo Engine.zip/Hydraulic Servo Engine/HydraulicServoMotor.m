%% Parameters
Dm = 30;
beta = 1*10^2;
V1 = 10;
V2 = 10;
BL = 3000;
Bm = 10;
JL = 1000;
Jm = 10;
Ps = 100;


%% Model
A = [0 1;
     -((2*Dm*beta*Dm)/(V1+V2))/(JL+Jm) -(BL+Bm)/(JL+Jm)];
B = [0 0;
     0 -(1)/(JL+Jm)];     
delay = 0;

%% State space for closed valve
servo_cl_valve = ss(delay, A, B);

%% State space for open valve
A = [0 1;
     0 -(BL+Bm)/(JL+Jm)];
     
B = [0 0;
     (Ps*Dm)/(JL+Jm) -(1)/(JL+Jm)];

servo_op_valve = ss(delay, A, B);

%% Input and time

t = linspace(0, 10, 200);
u = linspace(1, 1, 200);
TL = linspace(1, 100, 200); % Load

%% Simulation
lsim(servo_cl_valve, [u;TL], t);
figure
lsim(servo_op_valve, [u;TL], t);