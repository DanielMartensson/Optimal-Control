%% Parameters
m = 0.111;
R = 0.015;
g = -9.8;
L = 1.0;
d = 0.03;
J = 9.99e-6;

H = -m*g/(J/(R^2)+m);
A = [0 1 0 0
   0 0 H 0
   0 0 0 1
   0 0 0 0];
B = [0 0 0 1]';
C = [1 0 0 0];
D = [0];
delay = 0;

%% Model
ball_ss = ss(delay,A,B,C,D);

%% Control law - pole placement
p1 = -2+2i;
p2 = -2-2i;
p3 = -20;
p4 = -80;

L = acker(ball_ss,[p1,p2,p3,p4])

%% Feedback
sys_cl = reg(ball_ss, L)

%% Reference gain
sys_cl = referencegain(sys_cl);

%% Simulation
t = 0:0.01:5;
u = 0.25*ones(size(t));
[y,t,x] = lsim(sys_cl,u,t);