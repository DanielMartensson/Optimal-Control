%% Parameters
A = [-0.313 56.7 0; -0.0139 -0.426 0; 0 56.7 0];
B = [0.232; 0.0203; 0];
C = [0 0 1];
D = [0];
delay = 0;

%% Model
aircraft = ss(delay, A, B, C, D);

%% Conver to discrete
h = 0.2;
sysd = c2d(aircraft, h);

%% Linear Model Predictive Control
Np = 20; % Number prediction
r = 20; % Reference value
T = 50; % Time limit
a = 0.5; % Regularization
I = 0.2; % Integral action (max = 0, min = 1)

%% Simulation
[y, t, x, u] = lmpc(sysd, Np, r, T, a, I);

%% Show the input signals
figure
plot(t, u)
title('Input signal')
grid on
