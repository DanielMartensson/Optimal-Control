
%% Parameters
J = 0.01;
b = 0.1;
K = 0.01;
R = 1;
L = 0.5;

%% Model
A = [-b/J   K/J;
     -K/L   -R/L];
B = [0;
    1/L];
C = [1  0];
D = [0];
delay = 0;

motor_ss = ss(delay,A,B,C,D);

%% Reference model
etha = 0.7;
wn = 1;
Gref = tf(wn^2, [1 2*etha*wn  wn^2]);
step(Gref); 
title('Reference')
ylabel('y')

%% Get the poles and calculate the control law
p = pole(Gref);
L = acker(motor_ss, p)

%% Feedback
motor_ss_feedback = reg(motor_ss, L);
motor_ss_feedback_kr = referencegain(motor_ss_feedback);

%% Simulate
figure
step(motor_ss_feedback_kr);
title('Result')
ylabel('\theta', 'FontSize', 20)
