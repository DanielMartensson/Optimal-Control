%% Parameters
J = 0.01;
b = 0.1;
K = 0.01;
R = 1;
L = 0.5;

A = [0 1 0
    0 -b/J K/J
    0 -K/L -R/L];
B = [0 ; 0 ; 1/L];
C = [1  0  0;
     0  1  0];
D = [0;
     0];     
delay = 0;

%% Model
motor_ss = ss(delay,A,B,C,D);

%% Add integral action
Q = diag([0.1 0.01 0.1 0.1 0.1]);
R = 0.001;
[L, Li] = lqi(motor_ss, Q, R)

% Regulator
motor_ss_lqi = reg(motor_ss, L, Li);

% 
t = linspace(0, 30);
u = 45*ones(size(t)); % 45 degrees
lsim(motor_ss_lqi, u, t);
