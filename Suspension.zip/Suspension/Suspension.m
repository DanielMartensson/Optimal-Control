%% Parameters
m1 = 2.3;
m2 = 3.1;
k1 = 8.5;
k2 = 5.1;
b1 = 3.3;
b2 = 5.1;

A=[0                 1   0                                              0
  -(b1*b2)/(m1*m2)   0   ((b1/m1)*((b1/m1)+(b1/m2)+(b2/m2)))-(k1/m1)   -(b1/m1)
   b2/m2             0  -((b1/m1)+(b1/m2)+(b2/m2))                      1
   k2/m2             0  -((k1/m1)+(k1/m2)+(k2/m2))                      0];
B=[0;                 
   1/m1;              
   0;                
   (1/m1)+(1/m2)];
C=[0 0 1 0];
D=[0];
delay = 0;

%% Disturbance matrix
Bd = [0;
      (b1*b2)/(m1*m2);
      -(b2/m2);
      -(k2/m2)];

%% Noise matrix
Bn = 1; 

%% Model
sys = ss(delay,A,B,C,D)

%% LQR control
Q = C'*C;
R = 1
L = lqr(sys, Q, R)

%% LQE filter - Kalman
K = lqe(sys, Q, R);

%% Create feedback model
sys = referencegain(sys); % Better tracking!
sys_lqg = lqgreg(sys, L, K, Bd, 1); 


%% Inputs and time
t = linspace(0, 20, 300);
u = 4*ones(size(t));
d = randn(1, length(t)); % Disturbance
n = d;

%% Simulation
lsim(sys_lqg, [u; d; n], t);