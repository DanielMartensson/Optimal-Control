
%% Parameters
K = 100;
M = 10;
rho = 800;
A2 = 30;
A1 = 60;
a = 3;
L = 0.95;
Ps = 10;
B = 100;

%% Model
A = [0 1;
     -K/(M+rho*L*A2/a*A2) -B/(M+rho*L*A2/a*A2)];
     
B = [0 1;
     (Ps*A1)/(M+rho*L*A2/a*A2) -1/(M+rho*L*A2/a*A2)];
     
delay = 0;
servo_cylinder = ss(delay, A, B);

% Input and time
t = linspace(0, 6);
u = 1*ones(size(t));
FL = 10*ones(size(t));

%% Simulation
lsim(servo_cylinder, [u;FL], t);