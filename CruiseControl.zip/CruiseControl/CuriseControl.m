
%% Parameters
m = 1000; % Mass kg
b = 50; % Friction 

A = -b/m;
B = 1/m;
C = 1;
D = 0; % Does not need. ss function will auto generate D
delay = 0;

%% Model
cruise_ss = ss(delay,A,B,C,D);

%% Discrete model
h = 0.2; % sample time
cruise_ss_d = c2d(cruise_ss, h);

%% Reference model
K = 1; % Highest point
T = 1; % Time constant
G = tf(K, [T 1])
Gd = c2d(G, h);
step(Gd);
title('Reference')
ylabel('y')

%% Find the pole
p = pole(Gd)

%% Pole placement
L = acker(cruise_ss_d, [p])

% Compute the closed loop model
cruise_ss_d_cl = reg(cruise_ss_d, L);

%% Add reference gain for better tracking
cruise_ss_d_cl_kr = referencegain(cruise_ss_d_cl);

%% Simulate now
figure
y = step(cruise_ss_d_cl_kr);
title('Result')
ylabel('y')

